using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SYA_Load : MonoBehaviour
{
    public void OnButtonNext()
    {
        SceneManager.LoadScene(1);
    }
}
